Two Cards, One Way Home / bilingual free browser game
Open index.html, choose English or Japanese. Complete answer and ending included in both. No payment is required. Personal noncommercial play; no redistribution/resale/public uploads/commercial events. AI-assisted original fiction.
